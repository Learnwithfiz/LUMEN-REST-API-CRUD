<?php

/** @var \Laravel\Lumen\Routing\Router $router */
use App\Http\Controllers\ExampleController ;



$router->get('/', function () use ($router) {
    return $router->app->version();
});
$router->post('/order-entry','ExampleController@OnInsert');
$router->get('/product-display','ExampleController@OnSelect');
$router->get('/product-display/{prod_id}','ExampleController@prodDisplay');
$router->post('/product-update/{prod_id}','ExampleController@prodUpdate');
$router->get('/product-delete/{prod_id}','ExampleController@deleteProduct');
