<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Storage;
class ExampleController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        
    }
    public function OnInsert(Request $req)
    {
        $validation = Validator::make($req->all(),[
           'product_name'=>'required|string',
           'product_price'=>'required|numeric',
           'product_desc'=>'required|string',
           'product_title'=>'required|string',
            'img'=>'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048'
        ]);
        if ($validation->fails()) {
            return response()->json(['errors' => $validation->errors()], 422);
        }
        $prod_name = $req->input('product_name');
        $prod_price = $req->input('product_price');
        $prod_desc = $req->input('product_desc');
        $prod_title = $req->input('product_title');
        $file = $req->file('img'); 
        
        $fileExtension = $file->getClientOriginalExtension();
       
        $fileName = uniqid() . '.' . $fileExtension;
        $file->move('uploads', $fileName);
        
        $insert = DB::table('order_entry')->insert([
            'product_name'=>$prod_name,
            'product_price'=>$prod_price,
            'product_desc'=>$prod_desc,
            'product_title'=>$prod_title,
            'img'=>$fileName 
        ]);
        $Msg='';
        if($insert)
        {
            $Msg = "Product Added Successfull";
        }else{
            $Msg = "Product Added Failed";
        }
        return response()->json(['success'=>$Msg,'status_code'=>200]);
        
    }
    
    public function OnSelect()
    {
        $selectAllData = DB::table('order_entry')->get();
        return response()->json(['success'=>$selectAllData,'status_code'=>200]);
    }

    public function prodUpdate($prod_id,Request $req)
    {
       
        $prod_name = $req->input('product_name');
        $prod_price = $req->input('product_price');
        $prod_desc = $req->input('product_desc');
        $prod_title = $req->input('product_title');
        $file = $req->file('img');
    
        if ($file) 
       {
          $fileExtension = $file->getClientOriginalExtension();
          
          $fileName = uniqid() . '.' . $fileExtension;
          $file->move('uploads', $fileName);
       }else{
        $existingProduct = DB::table('order_entry')->where('id', $prod_id)->first();
       
        if ($existingProduct) {
            $fileName = $existingProduct->img;
        } else {
            $fileName = null;
        }

       }
       $insert = DB::table('order_entry')->where('id',$prod_id)->update(
          
        [
            'product_name' => $prod_name,
            'product_price' => $prod_price,
            'product_desc' => $prod_desc,
            'product_title' => $prod_title,
            'img' => $fileName 
        ]
    );
 
    $Msg = $insert ? "Product Added/Updated Successfully" : "Product Added/Updated Failed";
    return response()->json(['success' => $Msg, 'status_code' => 200]);
    }

    public function prodDisplay($prod_id)
    {
        $selectAllData = DB::table('order_entry')->where('id',$prod_id)->get();
        return response()->json(['data'=>$selectAllData,'status_code'=>200]);  
    }
    public function deleteProduct($prod_id,Request $req)
    {
       
    
        
        $product = DB::table('order_entry')->select('img')->where('id', $prod_id)->first();
            
        if (!$product) {
            return response()->json(['error' => 'Product not found'], 404);
        }
       
        $prodDelete = DB::table('order_entry')->where('id', $prod_id)->delete();
    
        
        if ($product->img) {
            $filePath = base_path('public/uploads/' . $product->img);
    
            if (file_exists($filePath)) {
                unlink($filePath); // Delete the file from the server
            }
        }
    
        return response()->json(['data' => 'Delete success', 'status_code' => 200]);
    }
}
